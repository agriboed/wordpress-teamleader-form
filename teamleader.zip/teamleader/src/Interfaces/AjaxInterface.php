<?php

namespace Teamleader\Interfaces;

/**
 * Interface AjaxInterface
 * @package Teamleader\Interfaces
 */
interface AjaxInterface {
	public function renderJson();
}